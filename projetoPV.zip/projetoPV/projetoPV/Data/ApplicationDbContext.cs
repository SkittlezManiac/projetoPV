﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using projetoPV.Models;

namespace projetoPV.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, IdentityRole<string>, string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // DbSet properties for your entities
        public DbSet<Morador> Moradores { get; set; }
        public DbSet<UnidadeHabitacional> UnidadesHabitacionais { get; set; }
        public DbSet<MembroFamilia> MembrosFamilia { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationship between Morador and UnidadeHabitacional
            modelBuilder.Entity<Morador>()
                .HasOne(m => m.UnidadeHabitacional)
                .WithMany(u => u.Moradores)
                .HasForeignKey(m => m.UnidadeId)
                .OnDelete(DeleteBehavior.Restrict); // Ensure no cascading delete

            // Configure relationship between Morador and MembroFamilia
            modelBuilder.Entity<MembroFamilia>()
                .HasOne(mf => mf.Morador)
                .WithMany(m => m.MembrosFamilia)
                .HasForeignKey(mf => mf.MoradorId)
                .OnDelete(DeleteBehavior.Restrict); // Ensure no cascading delete

            // Data seeding for roles
            modelBuilder.Entity<IdentityRole<string>>().HasData(
                new IdentityRole<string> { Id = "1", Name = "Admin", NormalizedName = "ADMIN" },
                new IdentityRole<string> { Id = "2", Name = "User", NormalizedName = "USER" }
            );

            // Seed initial ApplicationUser data
            modelBuilder.Entity<ApplicationUser>().HasData(
                new ApplicationUser
                {
                    Id = "1",
                    UserName = "joao@example.com",
                    NormalizedUserName = "JOAO@EXAMPLE.COM",
                    Email = "joao@example.com",
                    NormalizedEmail = "JOAO@EXAMPLE.COM",
                    EmailConfirmed = true,
                    SecurityStamp = "randomsecuritystamp1",
                    FirstName = "João",
                    LastName = "Silva"
                },
                new ApplicationUser
                {
                    Id = "2",
                    UserName = "maria@example.com",
                    NormalizedUserName = "MARIA@EXAMPLE.COM",
                    Email = "maria@example.com",
                    NormalizedEmail = "MARIA@EXAMPLE.COM",
                    EmailConfirmed = true,
                    SecurityStamp = "randomsecuritystamp2",
                    FirstName = "Maria",
                    LastName = "Souza"
                }
            );

            // Seed roles for users
            modelBuilder.Entity<IdentityUserRole<string>>().HasData(
                new IdentityUserRole<string> { RoleId = "1", UserId = "1" },
                new IdentityUserRole<string> { RoleId = "2", UserId = "2" }
            );

            // Seed initial UnidadeHabitacional data
            modelBuilder.Entity<UnidadeHabitacional>().HasData(
                new UnidadeHabitacional
                {
                    Id = 1,
                    Numero = "101",
                    Area = 100
                    // Add more properties as needed
                }
            );

            // Seed initial MembroFamilia data
            modelBuilder.Entity<MembroFamilia>().HasData(
                new MembroFamilia
                {
                    Id = 1,
                    Nome = "Fulano",
                    MoradorId = 1 // Relating to Morador with Id "1"
                    // Add more properties as needed
                }
            );

            // Example of setting precision for decimal properties
            modelBuilder.Entity<Alteracoes>()
                .Property(a => a.ValorPago)
                .HasPrecision(18, 2); // Adjust precision and scale as per your needs
        }
    }
}

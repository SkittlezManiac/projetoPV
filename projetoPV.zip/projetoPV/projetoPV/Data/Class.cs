﻿using Microsoft.EntityFrameworkCore;
using projetoPV.Models;

namespace projetoPV.Data
{
    public class SeuDbContext : DbContext
    {
        public SeuDbContext(DbContextOptions<SeuDbContext> options) : base(options)
        {
        }

        // Adicione aqui os DbSets para cada entidade do seu modelo
        public DbSet<Morador> Moradores { get; set; }

        // Outros DbSets podem ser adicionados conforme necessário

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Adicione aqui configurações personalizadas de modelagem, se necessário
        }
    }
}

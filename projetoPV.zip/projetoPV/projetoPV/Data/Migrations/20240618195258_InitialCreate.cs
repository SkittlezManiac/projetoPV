﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace projetoPV.Data.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UnidadesHabitacionais_UnidadeId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_MembrosFamilia_AspNetUsers_MoradorId",
                table: "MembrosFamilia");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: 1,
                column: "ConcurrencyStamp",
                value: "779a17d2-8e6f-4725-849c-068a7f9ded80");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: 2,
                column: "ConcurrencyStamp",
                value: "8f6a9272-47ca-4576-b266-50e854c79d35");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UnidadesHabitacionais_UnidadeId",
                table: "AspNetUsers",
                column: "UnidadeId",
                principalTable: "UnidadesHabitacionais",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_MembrosFamilia_AspNetUsers_MoradorId",
                table: "MembrosFamilia",
                column: "MoradorId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UnidadesHabitacionais_UnidadeId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_MembrosFamilia_AspNetUsers_MoradorId",
                table: "MembrosFamilia");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: 1,
                column: "ConcurrencyStamp",
                value: "ade3bbca-bd58-40aa-9b68-7074703f0a06");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: 2,
                column: "ConcurrencyStamp",
                value: "58a9ade3-ef31-44e8-9635-53e349e17623");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UnidadesHabitacionais_UnidadeId",
                table: "AspNetUsers",
                column: "UnidadeId",
                principalTable: "UnidadesHabitacionais",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MembrosFamilia_AspNetUsers_MoradorId",
                table: "MembrosFamilia",
                column: "MoradorId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}

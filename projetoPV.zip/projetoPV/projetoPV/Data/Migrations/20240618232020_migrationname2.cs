﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace projetoPV.Data.Migrations
{
    /// <inheritdoc />
    public partial class migrationname2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "d546672a-348e-4486-8d32-0da116edf21f");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "a8e82c2a-ca5a-4433-8974-8057bfe2b193");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "5c043b9d-1dbc-4d5f-9871-316f00696e92");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "0239e942-17dc-4a36-8904-856ba4b4012f");
        }
    }
}

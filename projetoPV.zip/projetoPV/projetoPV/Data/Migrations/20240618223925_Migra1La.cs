﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace projetoPV.Data.Migrations
{
    /// <inheritdoc />
    public partial class Migra1La : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "5c043b9d-1dbc-4d5f-9871-316f00696e92");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "0239e942-17dc-4a36-8904-856ba4b4012f");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "1",
                column: "ConcurrencyStamp",
                value: "d69b6176-7e59-4553-a47e-18bc27f0b8f0");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "2",
                column: "ConcurrencyStamp",
                value: "17efa2d4-506f-4152-a687-976a655063cd");
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace projetoPV.Models
{
    public class Avaliacao
    {
        public int Id { get; set; }
        public string Comentario { get; set; }
        public int Pontuacao { get; set; }
        public DateTime DataAvaliacao { get; set; }
        public int FornecedorID { get; set; }
        public List<Alteracoes> Alteracoes { get; set; }

        public Avaliacao(int id, string comentario, int pontuacao, DateTime dataAvaliacao, int fornecedorID, List<Alteracoes> alteracoes)
        {
            Id = id;
            Comentario = comentario;
            Pontuacao = pontuacao;
            DataAvaliacao = dataAvaliacao;
            FornecedorID = fornecedorID;
            Alteracoes = alteracoes ?? new List<Alteracoes>();
        }
    }
}

﻿using System.Collections.Generic;

namespace projetoPV.Models
{
    public class UnidadeHabitacional
    {
        public int Id { get; set; }
        public string? Numero { get; set; }
        public float Area { get; set; }
        public int MoradorAtualId { get; set; }
        public Morador? MoradorAtual { get; set; }
        public List<Morador> HistoricoMoradores { get; set; } = new List<Morador>(); // Inicialização da lista vazia
        public List<Alteracoes> Alteracoes { get; set; } = new List<Alteracoes>(); // Inicialização da lista vazia

        // Construtor padrão sem parâmetros necessário para o EF Core
        public UnidadeHabitacional()
        {
            Moradores = new List<Morador>(); // Inicializa a lista Moradores
        }

        public UnidadeHabitacional(int id, string? numero, float area, int moradorAtualId)
        {
            Id = id;
            Numero = numero;
            Area = area;
            MoradorAtualId = moradorAtualId;
            MoradorAtual = null; // Garanta que MoradorAtual seja inicializado como null, se necessário
            Moradores = new List<Morador>(); // Inicializa a lista Moradores
        }

        // Propriedade de navegação para Moradores
        public List<Morador> Moradores { get; set; }
    }
}


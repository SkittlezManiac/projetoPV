﻿using Microsoft.AspNetCore.Identity;

namespace projetoPV.Models
{
    public class ApplicationUser : IdentityUser<string>
    {
        // Additional properties for the user profile
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}

﻿namespace projetoPV.Models
{
    public class Pagamento
    {
        public int Id { get; set; }
        public DateTime DataPagamento { get; set; }
        public int UnidadeID { get; set; }
        public decimal ValorPago { get; set; }
        public string StatusPagamento { get; set; }

        public Pagamento(int id, DateTime dataPagamento, int unidadeID, decimal valorPago, string statusPagamento)
        {
            Id = id;
            DataPagamento = dataPagamento;
            UnidadeID = unidadeID;
            ValorPago = valorPago;
            StatusPagamento = statusPagamento;
        }
    }
}

﻿using System.Collections.Generic;

using System;

namespace projetoPV.Models
{
    public class Reserva
    {
        public int Id { get; set; }
        public int MoradorId { get; set; }
        public string AreaReservada { get; set; }
        public DateTime DataHoraReserva { get; set; }

        public Reserva(int id, int moradorId, string areaReservada, DateTime dataHoraReserva)
        {
            Id = id;
            MoradorId = moradorId;
            AreaReservada = areaReservada;
            DataHoraReserva = dataHoraReserva;
        }
    }
}

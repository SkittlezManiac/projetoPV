﻿using System.Collections.Generic;

namespace projetoPV.Models
{
    public class Fornecedor
    {
        public int Id { get; set; }
        public string NomeEmpresa { get; set; }
        public string TipoServico { get; set; }
        public string Contato { get; set; }
        public List<Avaliacao> Avaliacao { get; set; }

        public Fornecedor(int id, string nomeEmpresa, string tipoServico, string contato, List<Avaliacao> avaliacao)
        {
            Id = id;
            NomeEmpresa = nomeEmpresa;
            TipoServico = tipoServico;
            Contato = contato;
            Avaliacao = avaliacao ?? new List<Avaliacao>();
        }
    }
}

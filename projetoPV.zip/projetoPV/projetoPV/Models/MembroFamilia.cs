﻿using System.ComponentModel.DataAnnotations.Schema;

namespace projetoPV.Models
{
    public class MembroFamilia
    {
        public int Id { get; set; }
        public string? Nome { get; set; } // Non-nullable string for Nome
        public string? Parentesco { get; set; } // Non-nullable string for Parentesco
        public int MoradorId { get; set; } // FK for Morador

        // Navigation property
        [ForeignKey("MoradorId")] // Specify the FK relationship
        public virtual Morador? Morador { get; set; } // Navigation property to Morador

        public MembroFamilia()
        {
            // Constructor needed for EF Core
        }
    }
}

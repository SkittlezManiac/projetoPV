﻿using System.Collections.Generic;

namespace projetoPV.Models
{
    public class Morador
    {
        public int Id { get; set; } // Primary key for Morador
        public string? Nome { get; set; } // Name of the user
        public int UnidadeId { get; set; }
        public string? Contato { get; set; } // Contact information

        // Navigation properties
        public virtual ICollection<MembroFamilia> MembrosFamilia { get; set; } = new List<MembroFamilia>();
        public virtual UnidadeHabitacional? UnidadeHabitacional { get; set; }
        public virtual ICollection<Reserva> Reservas { get; set; } = new List<Reserva>();

        public Morador()
        {
            // Constructor
        }
    }
}

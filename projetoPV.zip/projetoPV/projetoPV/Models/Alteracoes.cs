﻿using System.Collections.Generic;

using System;

namespace projetoPV.Models
{
    public class Alteracoes
    {
        public int Id { get; set; }
        public DateTime DataAlteracao { get; set; }
        public int UnidadeID { get; set; }
        public decimal ValorPago { get; set; }

 
        public Alteracoes(int id, DateTime dataAlteracao, int unidadeID, decimal valorPago)
        {
            Id = id;
            DataAlteracao = dataAlteracao;
            UnidadeID = unidadeID;
            ValorPago = valorPago;
        }
    }
}

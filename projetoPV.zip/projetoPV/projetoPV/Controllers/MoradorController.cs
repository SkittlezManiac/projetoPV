﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using projetoPV.Data;
using projetoPV.Models;
using System.Linq;
using System.Threading.Tasks;

namespace projetoPV.Controllers
{
    public class MoradorController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MoradorController(ApplicationDbContext context)  // Alterado para ApplicationDbContext
        {
            _context = context;
        }

        // GET: Morador
        public async Task<IActionResult> Index()
        {
            return View(await _context.Moradores.ToListAsync());
        }

        // GET: Morador/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var morador = await _context.Moradores
                .FirstOrDefaultAsync(m => m.Id == id);
            if (morador == null)
            {
                return NotFound();
            }

            return View(morador);
        }

        // GET: Morador/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Morador/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Nome,UnidadeId,Contato")] Morador morador)
        {
            if (ModelState.IsValid)
            {
                _context.Add(morador);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(morador);
        }

        // GET: Morador/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var morador = await _context.Moradores.FindAsync(id);
            if (morador == null)
            {
                return NotFound();
            }
            return View(morador);
        }

        // POST: Morador/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nome,UnidadeId,Contato")] Morador morador)
        {
            if (id != morador.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(morador);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MoradorExists(morador.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(morador);
        }

        // GET: Morador/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var morador = await _context.Moradores
                .FirstOrDefaultAsync(m => m.Id == id);
            if (morador == null)
            {
                return NotFound();
            }

            return View(morador);
        }

        // POST: Morador/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var morador = await _context.Moradores.FindAsync(id);

            if (morador == null)
            {
                return NotFound(); // Retorna NotFound se o morador não for encontrado
            }

            _context.Moradores.Remove(morador);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MoradorExists(int id)
        {
            return _context.Moradores.Any(e => e.Id == id);
        }
    }
}

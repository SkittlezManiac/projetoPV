﻿using Microsoft.AspNetCore.Mvc;
using projetoPV.Models;
using projetoPV.Services;
using Microsoft.AspNetCore.Identity;
using System;
using System.Threading.Tasks;

namespace projetoPV.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly UserService _userService;

        public AccountController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            UserService userService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _userService = userService;
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    // Ensure required fields are not empty
                    if (string.IsNullOrEmpty(model.Email))
                    {
                        ModelState.AddModelError(nameof(model.Email), "Email is required.");
                        return View(model);
                    }

                    if (string.IsNullOrEmpty(model.Password))
                    {
                        ModelState.AddModelError(nameof(model.Password), "Password is required.");
                        return View(model);
                    }

                    // Ensure firstName and lastName are not null
                    string firstName = model.FirstName ?? string.Empty;
                    string lastName = model.LastName ?? string.Empty;

                    // Create a new ApplicationUser instance
                    var user = new ApplicationUser
                    {
                        UserName = model.Email,
                        Email = model.Email,
                        FirstName = firstName,
                        LastName = lastName
                    };

                    // Use UserManager to create the user with the given password
                    var result = await _userManager.CreateAsync(user, model.Password);

                    if (result.Succeeded)
                    {
                        // Automatically sign in the user
                        await _signInManager.SignInAsync(user, isPersistent: false);

                        // Redirect to home page or any desired page after successful registration
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        // If creation fails, add errors to ModelState
                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError(string.Empty, error.Description);
                        }
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError(string.Empty, ex.Message);
                }
            }

            // If we get here, something went wrong, return the view with the model
            return View(model);
        }
    }
}
